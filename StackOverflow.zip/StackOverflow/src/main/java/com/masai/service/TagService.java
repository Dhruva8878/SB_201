package com.masai.service;

import com.masai.model.Tag;

public interface TagService {
	public Tag createTag(Tag tag);
}

package com.masai.exception;

public class QuestionException extends Exception{
	public QuestionException() {
		// TODO Auto-generated constructor stub
	}
	public QuestionException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}

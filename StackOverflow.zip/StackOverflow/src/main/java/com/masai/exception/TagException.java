package com.masai.exception;

public class TagException extends Exception{
	public TagException() {
		// TODO Auto-generated constructor stub
	}
	
	public TagException(String msg) {
		super(msg);
	}
}
